"""Enhanced visualization utilities for 3D reconstruction pipeline.

Provides interactive 3D visualizations, diagnostic plots, and quality assessment tools.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D

LOG = logging.getLogger(__name__)


def plot_fragment_with_features(
    points: np.ndarray,
    normals: np.ndarray,
    break_mask: np.ndarray,
    break_score: np.ndarray,
    curvature: np.ndarray,
    normal_var: np.ndarray,
    roughness: np.ndarray,
    fragment_name: str,
    output_dir: Path,
) -> None:
    """Create comprehensive visualization of fragment features.
    
    Args:
        points: Point coordinates (N, 3)
        normals: Point normals (N, 3)
        break_mask: Binary break surface mask (N,)
        break_score: Break confidence scores (N,)
        curvature: Local curvature values (N,)
        normal_var: Normal variation values (N,)
        roughness: Surface roughness values (N,)
        fragment_name: Name for the fragment
        output_dir: Directory to save visualizations
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Subsample for visualization
    n_vis = min(5000, len(points))
    idx = np.linspace(0, len(points) - 1, n_vis, dtype=int)
    
    p = points[idx]
    break_m = break_mask[idx]
    break_s = break_score[idx]
    curv = curvature[idx]
    nvar = normal_var[idx]
    rough = roughness[idx]
    
    fig = plt.figure(figsize=(16, 10))
    
    # 1. Break surface classification
    ax1 = fig.add_subplot(2, 3, 1, projection='3d')
    colors = np.where(break_m, 'red', 'lightblue')
    ax1.scatter(p[:, 0], p[:, 1], p[:, 2], c=colors, s=2, alpha=0.6)
    ax1.set_title(f'{fragment_name}\nBreak Surface Detection')
    ax1.set_xlabel('X')
    ax1.set_ylabel('Y')
    ax1.set_zlabel('Z')
    
    # 2. Break confidence heatmap
    ax2 = fig.add_subplot(2, 3, 2, projection='3d')
    sc = ax2.scatter(p[:, 0], p[:, 1], p[:, 2], c=break_s, cmap='hot', s=2, alpha=0.7)
    plt.colorbar(sc, ax=ax2, shrink=0.5, label='Break Score')
    ax2.set_title('Break Confidence')
    ax2.set_xlabel('X')
    ax2.set_ylabel('Y')
    ax2.set_zlabel('Z')
    
    # 3. Curvature visualization
    ax3 = fig.add_subplot(2, 3, 3, projection='3d')
    sc = ax3.scatter(p[:, 0], p[:, 1], p[:, 2], c=curv, cmap='viridis', s=2, alpha=0.7)
    plt.colorbar(sc, ax=ax3, shrink=0.5, label='Curvature')
    ax3.set_title('Local Curvature')
    ax3.set_xlabel('X')
    ax3.set_ylabel('Y')
    ax3.set_zlabel('Z')
    
    # 4. Feature histograms
    ax4 = fig.add_subplot(2, 3, 4)
    ax4.hist(break_s, bins=50, alpha=0.7, color='darkred', edgecolor='black')
    ax4.axvline(break_s.mean(), color='blue', linestyle='--', label=f'Mean: {break_s.mean():.3f}')
    ax4.set_xlabel('Break Score')
    ax4.set_ylabel('Count')
    ax4.set_title('Break Score Distribution')
    ax4.legend()
    ax4.grid(alpha=0.3)
    
    # 5. Multi-feature histogram
    ax5 = fig.add_subplot(2, 3, 5)
    ax5.hist(curv, bins=40, alpha=0.5, label='Curvature', color='blue')
    ax5.hist(nvar, bins=40, alpha=0.5, label='Normal Var', color='green')
    ax5.hist(rough, bins=40, alpha=0.5, label='Roughness', color='orange')
    ax5.set_xlabel('Normalized Value')
    ax5.set_ylabel('Count')
    ax5.set_title('Feature Distributions')
    ax5.legend()
    ax5.grid(alpha=0.3)
    
    # 6. Statistics table
    ax6 = fig.add_subplot(2, 3, 6)
    ax6.axis('off')
    
    stats_text = f"""
Fragment Statistics:
━━━━━━━━━━━━━━━━━━━━━━
Points: {len(points):,}
Break points: {break_mask.sum():,} ({100*break_mask.mean():.1f}%)

Break Score:
  Mean: {break_score.mean():.4f}
  Std:  {break_score.std():.4f}
  Max:  {break_score.max():.4f}

Curvature:
  Mean: {curvature.mean():.4f}
  Std:  {curvature.std():.4f}

Normal Variation:
  Mean: {normal_var.mean():.4f}
  Std:  {normal_var.std():.4f}

Roughness:
  Mean: {roughness.mean():.4f}
  Std:  {roughness.std():.4f}
    """
    ax6.text(0.1, 0.5, stats_text, fontsize=10, family='monospace',
             verticalalignment='center')
    
    plt.suptitle(f'Fragment Analysis: {fragment_name}', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig(output_dir / f'{fragment_name}_features.png', dpi=150, bbox_inches='tight')
    plt.close()


def plot_pairwise_alignment_grid(
    fragments: List,
    alignments: Dict[Tuple[int, int], any],
    output_dir: Path,
    max_pairs: int = 9,
) -> None:
    """Create grid visualization of top alignment pairs.
    
    Args:
        fragments: List of Fragment objects
        alignments: Dictionary of alignment results
        output_dir: Output directory
        max_pairs: Maximum number of pairs to visualize
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Sort by quality
    sorted_pairs = sorted(
        alignments.items(),
        key=lambda x: (x[1].success, -x[1].inlier_rmse) if x[1].success else (False, float('inf')),
        reverse=True
    )[:max_pairs]
    
    n_pairs = len(sorted_pairs)
    if n_pairs == 0:
        return
    
    # Determine grid size
    ncols = 3
    nrows = (n_pairs + ncols - 1) // ncols
    
    fig = plt.figure(figsize=(5 * ncols, 5 * nrows))
    
    by_idx = {f.idx: f for f in fragments}
    
    for idx, ((i, j), result) in enumerate(sorted_pairs):
        ax = fig.add_subplot(nrows, ncols, idx + 1, projection='3d')
        
        # Transform source to target
        src_pts = by_idx[i].points
        tgt_pts = by_idx[j].points
        
        homo = np.hstack([src_pts, np.ones((src_pts.shape[0], 1))])
        aligned = (homo @ result.transform_ij.T)[:, :3]
        
        # Sample for visualization
        src_sample = aligned[::max(1, len(aligned) // 500)]
        tgt_sample = tgt_pts[::max(1, len(tgt_pts) // 500)]
        
        ax.scatter(src_sample[:, 0], src_sample[:, 1], src_sample[:, 2],
                  c='red', s=1, alpha=0.6, label=by_idx[i].name)
        ax.scatter(tgt_sample[:, 0], tgt_sample[:, 1], tgt_sample[:, 2],
                  c='blue', s=1, alpha=0.6, label=by_idx[j].name)
        
        status = '✓' if result.success else '✗'
        ax.set_title(
            f'{status} {by_idx[i].name} ↔ {by_idx[j].name}\n'
            f'RMSE: {result.inlier_rmse:.4f}, Fitness: {result.fitness:.3f}',
            fontsize=9
        )
        ax.legend(fontsize=7)
        ax.set_xlabel('X', fontsize=7)
        ax.set_ylabel('Y', fontsize=7)
        ax.set_zlabel('Z', fontsize=7)
    
    plt.suptitle('Pairwise Alignment Results', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig(output_dir / 'alignment_grid.png', dpi=150, bbox_inches='tight')
    plt.close()


def plot_reconstruction_quality_report(
    metrics: Dict,
    alignments: Dict,
    assembly: any,
    output_path: Path,
) -> None:
    """Generate comprehensive quality report visualization.
    
    Args:
        metrics: Metrics dictionary
        alignments: Alignment results
        assembly: Assembly result
        output_path: Output file path
    """
    fig = plt.figure(figsize=(14, 10))
    
    # 1. Alignment quality distribution
    ax1 = fig.add_subplot(2, 3, 1)
    rmses = [r.inlier_rmse for r in alignments.values() if r.success and np.isfinite(r.inlier_rmse)]
    if rmses:
        ax1.hist(rmses, bins=20, color='steelblue', edgecolor='black', alpha=0.7)
        ax1.axvline(np.mean(rmses), color='red', linestyle='--', linewidth=2,
                   label=f'Mean: {np.mean(rmses):.4f}')
        ax1.set_xlabel('ICP RMSE')
        ax1.set_ylabel('Count')
        ax1.set_title('Alignment Quality Distribution')
        ax1.legend()
        ax1.grid(alpha=0.3)
    
    # 2. Success rate
    ax2 = fig.add_subplot(2, 3, 2)
    total = len(alignments)
    successful = sum(1 for r in alignments.values() if r.success)
    failed = total - successful
    
    ax2.pie([successful, failed], labels=['Successful', 'Failed'],
           colors=['#2ecc71', '#e74c3c'], autopct='%1.1f%%', startangle=90)
    ax2.set_title(f'Alignment Success Rate\n({successful}/{total} pairs)')
    
    # 3. Chamfer distance distribution
    ax3 = fig.add_subplot(2, 3, 3)
    chamfers = [r.chamfer for r in alignments.values() if r.success and np.isfinite(r.chamfer)]
    if chamfers:
        ax3.hist(chamfers, bins=20, color='coral', edgecolor='black', alpha=0.7)
        ax3.axvline(np.mean(chamfers), color='blue', linestyle='--', linewidth=2,
                   label=f'Mean: {np.mean(chamfers):.4f}')
        ax3.set_xlabel('Chamfer Distance')
        ax3.set_ylabel('Count')
        ax3.set_title('Chamfer Distance Distribution')
        ax3.legend()
        ax3.grid(alpha=0.3)
    
    # 4. Graph connectivity
    ax4 = fig.add_subplot(2, 3, 4)
    n_nodes = assembly.graph.number_of_nodes()
    n_edges = assembly.graph.number_of_edges()
    n_mst_edges = assembly.mst.number_of_edges()
    
    bars = ax4.bar(['Nodes', 'Graph Edges', 'MST Edges'],
                   [n_nodes, n_edges, n_mst_edges],
                   color=['#3498db', '#9b59b6', '#e67e22'])
    ax4.set_ylabel('Count')
    ax4.set_title('Reconstruction Graph Statistics')
    ax4.grid(axis='y', alpha=0.3)
    
    for bar in bars:
        height = bar.get_height()
        ax4.text(bar.get_x() + bar.get_width()/2., height,
                f'{int(height)}', ha='center', va='bottom')
    
    # 5. Key metrics table
    ax5 = fig.add_subplot(2, 3, 5)
    ax5.axis('off')
    
    metrics_text = f"""
KEY METRICS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Reconstruction:
  Completeness:      {metrics.get('reconstruction_completeness', 0):.2%}
  Assembled Frags:   {metrics.get('assembled_fragments', 0)}

Alignment:
  Mean ICP RMSE:     {metrics.get('mean_icp_rmse', float('nan')):.5f}
  Mean Chamfer:      {metrics.get('mean_chamfer_distance', float('nan')):.5f}
  Successful:        {metrics.get('successful_alignments', 0)}/{metrics.get('aligned_pairs', 0)}

Graph:
  Nodes:             {metrics.get('graph_nodes', 0)}
  Edges:             {metrics.get('graph_edges', 0)}

Matching:
  Accuracy:          {metrics.get('pairwise_match_accuracy', float('nan')):.2%}
  Required:          {metrics.get('min_required_accuracy', 0):.2%}
  Split:             {metrics.get('evaluation_split', 'N/A')}
    """
    
    ax5.text(0.1, 0.5, metrics_text, fontsize=11, family='monospace',
            verticalalignment='center')
    
    # 6. Overall quality gauge
    ax6 = fig.add_subplot(2, 3, 6)
    ax6.axis('off')
    
    completeness = metrics.get('reconstruction_completeness', 0)
    success_rate = successful / max(total, 1)
    match_acc = metrics.get('pairwise_match_accuracy', 0)
    if not np.isfinite(match_acc):
        match_acc = 0.0
    
    overall_quality = (0.4 * completeness + 0.3 * success_rate + 0.3 * match_acc)
    
    # Draw gauge
    theta = np.linspace(0, np.pi, 100)
    radius = 0.8
    x = radius * np.cos(theta)
    y = radius * np.sin(theta)
    
    ax6.plot(x, y, 'k-', linewidth=3)
    ax6.fill_between(x, 0, y, alpha=0.3, color='lightgray')
    
    # Color zones
    zones = [
        (0, 0.5, 'red', 'Poor'),
        (0.5, 0.7, 'orange', 'Fair'),
        (0.7, 0.85, 'yellow', 'Good'),
        (0.85, 1.0, 'green', 'Excellent'),
    ]
    
    for start, end, color, label in zones:
        theta_zone = np.linspace(start * np.pi, end * np.pi, 50)
        x_zone = radius * np.cos(theta_zone)
        y_zone = radius * np.sin(theta_zone)
        ax6.fill_between(x_zone, 0, y_zone, alpha=0.5, color=color)
    
    # Needle
    angle = overall_quality * np.pi
    ax6.plot([0, radius * np.cos(angle)], [0, radius * np.sin(angle)],
            'r-', linewidth=4)
    ax6.plot(0, 0, 'ko', markersize=10)
    
    ax6.set_xlim(-1, 1)
    ax6.set_ylim(-0.2, 1)
    ax6.set_aspect('equal')
    ax6.set_title(f'Overall Quality: {overall_quality:.1%}', fontsize=12, fontweight='bold')
    
    plt.suptitle('Reconstruction Quality Report', fontsize=16, fontweight='bold')
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()


def export_reconstruction_to_ply(
    points: np.ndarray,
    colors: Optional[np.ndarray],
    normals: Optional[np.ndarray],
    output_path: Path,
) -> None:
    """Export colored reconstruction to PLY file.
    
    Args:
        points: Point coordinates (N, 3)
        colors: RGB colors (N, 3) in range [0, 1], optional
        normals: Point normals (N, 3), optional
        output_path: Output PLY file path
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    with output_path.open('w') as f:
        f.write("ply\n")
        f.write("format ascii 1.0\n")
        f.write(f"element vertex {len(points)}\n")
        f.write("property float x\n")
        f.write("property float y\n")
        f.write("property float z\n")
        
        if normals is not None:
            f.write("property float nx\n")
            f.write("property float ny\n")
            f.write("property float nz\n")
        
        if colors is not None:
            f.write("property uchar red\n")
            f.write("property uchar green\n")
            f.write("property uchar blue\n")
        
        f.write("end_header\n")
        
        for i in range(len(points)):
            line = f"{points[i, 0]:.6f} {points[i, 1]:.6f} {points[i, 2]:.6f}"
            
            if normals is not None:
                line += f" {normals[i, 0]:.6f} {normals[i, 1]:.6f} {normals[i, 2]:.6f}"
            
            if colors is not None:
                rgb = (np.clip(colors[i], 0, 1) * 255).astype(int)
                line += f" {rgb[0]} {rgb[1]} {rgb[2]}"
            
            f.write(line + "\n")
    
    LOG.info(f"Exported reconstruction to {output_path}")
