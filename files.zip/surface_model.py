"""Point-wise surface classification model for break vs original surface detection.

This module implements a PointNet-style architecture for classifying individual points
as belonging to break surfaces or original surfaces.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import classification_report, confusion_matrix
from torch.utils.data import DataLoader, Dataset

LOG = logging.getLogger(__name__)


class PointwiseDataset(Dataset):
    """Dataset for point-wise surface classification."""

    def __init__(self, features: np.ndarray, labels: np.ndarray):
        """
        Args:
            features: (N, D) array of per-point features
            labels: (N,) array of binary labels (0=original, 1=break)
        """
        self.features = torch.from_numpy(features.astype(np.float32))
        self.labels = torch.from_numpy(labels.astype(np.int64))

    def __len__(self) -> int:
        return len(self.labels)

    def __getitem__(self, idx: int):
        return self.features[idx], self.labels[idx]


class PointwiseClassifier(nn.Module):
    """MLP-based point classifier for break surface detection.
    
    Simple yet effective architecture for classifying individual points
    based on local geometric features.
    """

    def __init__(self, in_dim: int, hidden_dims: Tuple[int, ...] = (128, 64, 32)):
        super().__init__()
        layers = []
        prev_dim = in_dim
        
        for hidden_dim in hidden_dims:
            layers.extend([
                nn.Linear(prev_dim, hidden_dim),
                nn.ReLU(inplace=True),
                nn.BatchNorm1d(hidden_dim),
                nn.Dropout(0.2),
            ])
            prev_dim = hidden_dim
        
        layers.append(nn.Linear(prev_dim, 2))  # Binary classification
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


@dataclass
class TrainingMetrics:
    """Training metrics for surface classification."""
    
    train_loss: np.ndarray
    val_loss: np.ndarray
    train_acc: np.ndarray
    val_acc: np.ndarray
    best_epoch: int
    best_val_acc: float


def train_surface_classifier(
    train_features: np.ndarray,
    train_labels: np.ndarray,
    val_features: Optional[np.ndarray] = None,
    val_labels: Optional[np.ndarray] = None,
    models_dir: Path = Path("models"),
    hidden_dims: Tuple[int, ...] = (128, 64, 32),
    epochs: int = 100,
    batch_size: int = 256,
    lr: float = 1e-3,
    weight_decay: float = 1e-4,
    device: str = "cpu",
) -> Tuple[PointwiseClassifier, TrainingMetrics]:
    """Train point-wise surface classifier.
    
    Args:
        train_features: Training features (N, D)
        train_labels: Training labels (N,) with 0=original, 1=break
        val_features: Optional validation features
        val_labels: Optional validation labels
        models_dir: Directory to save model checkpoints
        hidden_dims: Hidden layer dimensions
        epochs: Number of training epochs
        batch_size: Batch size
        lr: Learning rate
        weight_decay: L2 regularization
        device: Device to train on
        
    Returns:
        Trained model and training metrics
    """
    models_dir.mkdir(parents=True, exist_ok=True)
    
    # Create datasets
    train_ds = PointwiseDataset(train_features, train_labels)
    train_dl = DataLoader(train_ds, batch_size=batch_size, shuffle=True, drop_last=False)
    
    has_val = val_features is not None and val_labels is not None
    if has_val:
        val_ds = PointwiseDataset(val_features, val_labels)
        val_dl = DataLoader(val_ds, batch_size=batch_size, shuffle=False)
    
    # Initialize model
    model = PointwiseClassifier(in_dim=train_features.shape[1], hidden_dims=hidden_dims).to(device)
    
    # Loss with class weighting for imbalanced data
    class_counts = np.bincount(train_labels, minlength=2)
    class_weights = len(train_labels) / (2.0 * class_counts + 1e-10)
    criterion = nn.CrossEntropyLoss(
        weight=torch.FloatTensor(class_weights).to(device)
    )
    
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='max', factor=0.5, patience=10, verbose=True
    )
    
    # Training loop
    train_losses = []
    val_losses = []
    train_accs = []
    val_accs = []
    best_val_acc = 0.0
    best_epoch = 0
    
    for epoch in range(epochs):
        # Training
        model.train()
        total_loss = 0.0
        correct = 0
        total = 0
        
        for features, labels in train_dl:
            features = features.to(device)
            labels = labels.to(device)
            
            outputs = model(features)
            loss = criterion(outputs, labels)
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            total_loss += loss.item() * features.size(0)
            _, predicted = outputs.max(1)
            correct += predicted.eq(labels).sum().item()
            total += labels.size(0)
        
        train_loss = total_loss / total
        train_acc = correct / total
        train_losses.append(train_loss)
        train_accs.append(train_acc)
        
        # Validation
        if has_val:
            model.eval()
            val_total_loss = 0.0
            val_correct = 0
            val_total = 0
            
            with torch.no_grad():
                for features, labels in val_dl:
                    features = features.to(device)
                    labels = labels.to(device)
                    
                    outputs = model(features)
                    loss = criterion(outputs, labels)
                    
                    val_total_loss += loss.item() * features.size(0)
                    _, predicted = outputs.max(1)
                    val_correct += predicted.eq(labels).sum().item()
                    val_total += labels.size(0)
            
            val_loss = val_total_loss / val_total
            val_acc = val_correct / val_total
            val_losses.append(val_loss)
            val_accs.append(val_acc)
            
            scheduler.step(val_acc)
            
            # Save best model
            if val_acc > best_val_acc:
                best_val_acc = val_acc
                best_epoch = epoch
                torch.save({
                    'epoch': epoch,
                    'model_state_dict': model.state_dict(),
                    'optimizer_state_dict': optimizer.state_dict(),
                    'val_acc': val_acc,
                    'hidden_dims': hidden_dims,
                    'in_dim': train_features.shape[1],
                }, models_dir / "surface_classifier_best.pt")
            
            if (epoch + 1) % 10 == 0 or epoch == 0:
                LOG.info(
                    f"Epoch {epoch+1}/{epochs} - "
                    f"Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.4f} - "
                    f"Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.4f}"
                )
        else:
            val_losses.append(0.0)
            val_accs.append(0.0)
            
            if (epoch + 1) % 10 == 0 or epoch == 0:
                LOG.info(
                    f"Epoch {epoch+1}/{epochs} - "
                    f"Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.4f}"
                )
    
    # Plot training curves
    plot_training_curves(
        train_losses, val_losses if has_val else None,
        train_accs, val_accs if has_val else None,
        models_dir / "surface_classifier_training.png"
    )
    
    metrics = TrainingMetrics(
        train_loss=np.array(train_losses),
        val_loss=np.array(val_losses),
        train_acc=np.array(train_accs),
        val_acc=np.array(val_accs),
        best_epoch=best_epoch,
        best_val_acc=best_val_acc,
    )
    
    LOG.info(f"Training complete. Best val acc: {best_val_acc:.4f} at epoch {best_epoch+1}")
    
    return model, metrics


def predict_surface_labels(
    model: PointwiseClassifier,
    features: np.ndarray,
    device: str = "cpu",
    batch_size: int = 1024,
) -> Tuple[np.ndarray, np.ndarray]:
    """Predict surface labels for points.
    
    Args:
        model: Trained classifier
        features: Point features (N, D)
        device: Device to run on
        batch_size: Batch size for inference
        
    Returns:
        predictions: (N,) array of predicted labels (0 or 1)
        probabilities: (N, 2) array of class probabilities
    """
    model.eval()
    model.to(device)
    
    predictions = []
    probabilities = []
    
    with torch.no_grad():
        for i in range(0, len(features), batch_size):
            batch = torch.from_numpy(
                features[i:i+batch_size].astype(np.float32)
            ).to(device)
            
            outputs = model(batch)
            probs = torch.softmax(outputs, dim=1)
            _, preds = outputs.max(1)
            
            predictions.append(preds.cpu().numpy())
            probabilities.append(probs.cpu().numpy())
    
    return (
        np.concatenate(predictions),
        np.concatenate(probabilities, axis=0)
    )


def evaluate_classifier(
    model: PointwiseClassifier,
    features: np.ndarray,
    labels: np.ndarray,
    device: str = "cpu",
    output_dir: Optional[Path] = None,
) -> dict:
    """Evaluate classifier performance.
    
    Args:
        model: Trained classifier
        features: Test features
        labels: True labels
        device: Device to run on
        output_dir: Optional directory to save evaluation plots
        
    Returns:
        Dictionary of evaluation metrics
    """
    predictions, probabilities = predict_surface_labels(model, features, device)
    
    # Compute metrics
    accuracy = (predictions == labels).mean()
    
    # Per-class metrics
    report = classification_report(
        labels, predictions,
        target_names=['Original', 'Break'],
        output_dict=True,
        zero_division=0
    )
    
    cm = confusion_matrix(labels, predictions)
    
    metrics = {
        'accuracy': float(accuracy),
        'precision_break': float(report['Break']['precision']),
        'recall_break': float(report['Break']['recall']),
        'f1_break': float(report['Break']['f1-score']),
        'precision_original': float(report['Original']['precision']),
        'recall_original': float(report['Original']['recall']),
        'f1_original': float(report['Original']['f1-score']),
        'confusion_matrix': cm.tolist(),
    }
    
    LOG.info(f"Evaluation - Accuracy: {accuracy:.4f}")
    LOG.info(f"Break Surface - Precision: {metrics['precision_break']:.4f}, "
             f"Recall: {metrics['recall_break']:.4f}, F1: {metrics['f1_break']:.4f}")
    
    # Plot confusion matrix
    if output_dir is not None:
        output_dir.mkdir(parents=True, exist_ok=True)
        plot_confusion_matrix(cm, output_dir / "confusion_matrix.png")
    
    return metrics


def plot_training_curves(
    train_loss: list,
    val_loss: Optional[list],
    train_acc: list,
    val_acc: Optional[list],
    output_path: Path,
) -> None:
    """Plot training curves."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
    
    # Loss
    ax1.plot(train_loss, label='Train', color='tab:blue', linewidth=2)
    if val_loss is not None:
        ax1.plot(val_loss, label='Validation', color='tab:orange', linewidth=2)
    ax1.set_xlabel('Epoch')
    ax1.set_ylabel('Loss')
    ax1.set_title('Training Loss')
    ax1.legend()
    ax1.grid(alpha=0.3)
    
    # Accuracy
    ax2.plot(train_acc, label='Train', color='tab:blue', linewidth=2)
    if val_acc is not None:
        ax2.plot(val_acc, label='Validation', color='tab:orange', linewidth=2)
    ax2.set_xlabel('Epoch')
    ax2.set_ylabel('Accuracy')
    ax2.set_title('Classification Accuracy')
    ax2.legend()
    ax2.grid(alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150)
    plt.close()


def plot_confusion_matrix(cm: np.ndarray, output_path: Path) -> None:
    """Plot confusion matrix."""
    fig, ax = plt.subplots(figsize=(6, 5))
    
    im = ax.imshow(cm, cmap='Blues')
    ax.set_xticks([0, 1])
    ax.set_yticks([0, 1])
    ax.set_xticklabels(['Original', 'Break'])
    ax.set_yticklabels(['Original', 'Break'])
    
    # Add text annotations
    for i in range(2):
        for j in range(2):
            text = ax.text(j, i, str(cm[i, j]),
                          ha="center", va="center", color="black", fontsize=14)
    
    ax.set_xlabel('Predicted')
    ax.set_ylabel('True')
    ax.set_title('Confusion Matrix')
    
    plt.colorbar(im, ax=ax)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150)
    plt.close()
