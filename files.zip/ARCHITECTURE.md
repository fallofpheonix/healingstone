# Healing Stones: Architecture & Improvements

## Overview

The Healing Stones pipeline is a complete ML system for reconstructing fragmented 3D cultural artifacts from scanned pieces. This document describes the architecture, recent improvements, and best practices.

## Architecture

### Core Pipeline Flow

```
Fragment Files (.PLY/.OBJ)
         ↓
    Preprocessing
    - Denoising
    - Downsampling  
    - Normalization
    - Normal estimation
         ↓
    Feature Extraction (with caching)
    - Break surface detection
    - FPFH descriptors
    - Fragment descriptors
         ↓
    Machine Learning
    - Siamese network training
    - Contrastive learning
    - Self-supervised augmentation
         ↓
    Fragment Matching
    - Similarity matrix
    - Reciprocal top-k filtering
    - Candidate pair generation
         ↓
    Pairwise Alignment
    - RANSAC coarse alignment
    - ICP refinement
    - Quality scoring
         ↓
    Global Reconstruction
    - Graph construction
    - MST extraction
    - Global transform propagation
    - Mesh merging
         ↓
    Output Artifacts
    - Reconstructed model
    - Metrics & diagnostics
    - Visualizations
```

### Module Organization

```
src/healingstone/
├── preprocess.py           # Data loading & preprocessing
├── features.py             # Feature extraction & caching
├── surface_model.py        # NEW: Point-wise classification
├── train_model.py          # Siamese network training
├── match_fragments.py      # Fragment matching logic
├── align_fragments.py      # Pairwise alignment
├── reconstruct.py          # Global assembly
├── visualization.py        # NEW: Enhanced visualizations
├── run_pipeline.py         # Main orchestration
├── runtime_config.py       # Configuration management
├── runtime_paths.py        # Path resolution
├── metrics_schema.py       # Metrics validation
├── test_pipeline.py        # Synthetic testing
└── healing_stones.py       # Legacy monolithic version
```

## Recent Improvements

### 1. Surface Classification Model (`surface_model.py`)

**What it does:**
- Point-wise classification of break vs original surfaces
- PointNet-style neural network architecture
- Training with class-balanced loss
- Validation and evaluation metrics

**Key features:**
- MLP classifier with batch normalization and dropout
- Handles class imbalance automatically
- Generates training curves and confusion matrices
- Supports validation split for model selection

**Usage:**
```python
from healingstone.surface_model import train_surface_classifier, predict_surface_labels

# Train model
model, metrics = train_surface_classifier(
    train_features=features_train,
    train_labels=labels_train,
    val_features=features_val,
    val_labels=labels_val,
    models_dir=Path("models"),
    epochs=100,
)

# Predict on new data
predictions, probabilities = predict_surface_labels(
    model=model,
    features=new_features,
    device="cpu",
)
```

### 2. Enhanced Visualizations (`visualization.py`)

**What it does:**
- Comprehensive fragment feature visualization
- Alignment quality grid views
- Reconstruction quality reports
- Export utilities

**Key visualizations:**

1. **Fragment Feature Analysis**
   - 3D break surface overlay
   - Heatmaps (curvature, roughness, normal variation)
   - Feature distribution histograms
   - Statistical summaries

2. **Alignment Grid**
   - Side-by-side before/after views
   - Quality metrics per pair
   - Success/failure indicators

3. **Quality Report Dashboard**
   - Alignment quality distributions
   - Success rate pie charts
   - Graph connectivity statistics
   - Overall quality gauge

**Usage:**
```python
from healingstone.visualization import (
    plot_fragment_with_features,
    plot_pairwise_alignment_grid,
    plot_reconstruction_quality_report,
)

# Visualize fragment features
plot_fragment_with_features(
    points=fragment.points,
    normals=fragment.normals,
    break_mask=features.break_mask,
    break_score=features.break_score,
    curvature=features.curvature,
    normal_var=features.normal_var,
    roughness=features.roughness,
    fragment_name=fragment.name,
    output_dir=results_dir,
)

# Create quality report
plot_reconstruction_quality_report(
    metrics=metrics,
    alignments=alignments,
    assembly=assembly,
    output_path=results_dir / "quality_report.png",
)
```

### 3. Feature Caching

**What it does:**
- Persistent caching of expensive feature computations
- Content-based cache invalidation
- Stable hashing for reproducibility

**Benefits:**
- 10-50x speedup on repeated runs
- Enables rapid iteration on matching/alignment
- Automatic cache invalidation on parameter changes

**Cache structure:**
```
artifacts/runs/<run_id>/cache/
├── fragment_001_<hash>.npz       # Cached features
├── fragment_001_<hash>.json      # Cache metadata
├── fragment_002_<hash>.npz
└── ...
```

## Configuration System

### Precedence Rules

Configuration follows strict precedence: **CLI > ENV > YAML**

```bash
# YAML config (lowest priority)
cat configs/pipeline.yaml
# voxel_size: 0.01

# Environment override (medium priority)
export HEALINGSTONE_VOXEL_SIZE=0.02

# CLI override (highest priority)
python -m healingstone.run_pipeline --voxel-size 0.03
# Final value: 0.03
```

### Config Versioning

All configs require a `config_version` field:

```yaml
# configs/pipeline.yaml
config_version: 1  # Required!
dataset_alias: 3d
voxel_size: 0.01
...
```

Unsupported versions fail fast with clear error messages.

### Dataset Aliases

Map friendly names to dataset paths:

```yaml
# configs/datasets.yaml
aliases:
  3d: data/raw/v1
  stele: data/raw/stele_fragments
  pottery: data/raw/pottery_shards
```

Usage:
```bash
# Use alias
python -m healingstone.run_pipeline --dataset-alias stele

# Or explicit path
python -m healingstone.run_pipeline --data-dir /path/to/fragments
```

## Run Artifacts

Each run creates a timestamped directory:

```
artifacts/runs/20260315T143022Z_a1b2c3d/
├── results/
│   ├── reconstructed_model.ply
│   ├── similarity_matrix.png
│   ├── alignment_metrics.json
│   ├── final_reconstruction.png
│   └── labeling_candidates.csv
├── models/
│   ├── siamese_encoder.pt
│   └── training_loss.png
├── logs/
│   └── pipeline.log
├── cache/
│   └── <cached_features>
├── run_metadata.json
└── resolved_paths.json
```

Convenience pointer:
```bash
ls -l artifacts/latest  # → symlink to most recent run
```

## Metrics & Quality Gates

### Required Metrics Schema

Every run must produce these metrics:

```json
{
  "pairwise_match_accuracy": 0.85,
  "min_required_accuracy": 0.80,
  "evaluation_split": "test",
  "aligned_pairs": 12,
  "successful_alignments": 10,
  "mean_icp_rmse": 0.0123,
  "mean_chamfer_distance": 0.21,
  "reconstruction_completeness": 0.92,
  "assembled_fragments": 8,
  "graph_nodes": 8,
  "graph_edges": 10,
  "metrics_schema_version": 1
}
```

### Accuracy Gate

When `min_required_accuracy > 0`, the pipeline enforces a hard gate:

```python
if pairwise_match_accuracy < min_required_accuracy:
    raise RuntimeError("Accuracy requirement not met")
```

Requirements:
- Must use `evaluation_split: test`
- Must provide labeled pairs CSV
- Must have at least 1 labeled pair

## Testing Strategy

### 1. Unit Tests

Located in `tests/`:
- `test_runtime_config.py` - Config precedence
- `test_runtime_paths.py` - Path resolution  
- `test_metrics_schema.py` - Schema validation
- `test_deterministic_metrics.py` - Reproducibility
- `test_cli_wrappers.py` - CLI interface

Run with:
```bash
pytest
```

### 2. Synthetic Testing

Generate synthetic fragments and validate end-to-end:

```bash
python -m healingstone.test_pipeline --n-fragments 8
```

This creates:
- Synthetic stele fragments with known adjacencies
- Ground truth pair labels
- Full pipeline execution
- Precision/recall evaluation

### 3. Integration Testing

Test on real data subsets:

```bash
# Small dataset for quick validation
python -m healingstone.run_pipeline \
    --data-dir data/raw/sample_3_fragments \
    --output-dir artifacts
```

## Performance Optimization

### Memory Management

For large meshes:
1. **Adjust sample points**: `--sample-points 20000` (default: 40000)
2. **Increase voxel size**: `--voxel-size 0.02` (default: 0.01)
3. **Reduce FPFH neighbors**: `--fpfh-max-nn 50` (default: 100)

### Computation Speed

1. **Use caching**: Features cached after first run
2. **GPU acceleration**: `--device cuda` (requires CUDA-enabled PyTorch)
3. **Reduce candidates**: `--candidate-top-k 3` (default: 4)

### Parallel Processing

The pipeline is deterministic but CPU-bound. Future improvements:
- Parallelize feature extraction across fragments
- Batch alignment operations
- Distributed graph optimization

## Common Workflows

### New Dataset Setup

1. Organize fragments:
```bash
mkdir -p data/raw/my_dataset
cp /source/*.ply data/raw/my_dataset/
```

2. Register alias:
```yaml
# configs/datasets.yaml
aliases:
  my_dataset: data/raw/my_dataset
```

3. Run pipeline:
```bash
python -m healingstone.run_pipeline --dataset-alias my_dataset
```

### Iterative Labeling

1. Initial run generates candidates:
```bash
python -m healingstone.run_pipeline
# Creates: artifacts/latest/results/labeling_candidates.csv
```

2. Annotate pairs:
```csv
frag_a,frag_b,label,score,source
fragment_01,fragment_02,1,0.872,high_confidence
fragment_03,fragment_04,0,0.451,ambiguous
...
```

3. Re-run with labels:
```bash
python -m healingstone.run_pipeline \
    --labels-csv artifacts/latest/results/labeling_candidates.csv
```

4. Monitor accuracy improvement in metrics.

### Hyperparameter Tuning

Create sweep configs:

```yaml
# configs/pipeline_tuned.yaml
config_version: 1
candidate_top_k: 6        # Increased from 4
align_top_n: 15           # Increased from 10
threshold_objective: f1   # Changed from accuracy
```

Run comparison:
```bash
python -m healingstone.run_pipeline --config configs/pipeline_tuned.yaml
```

Compare metrics across runs.

## Troubleshooting

### Low Matching Accuracy

**Symptoms:** `pairwise_match_accuracy < 0.5`

**Solutions:**
1. Check data quality:
   - Are fragments well-scanned?
   - Are there enough break surfaces?
   - Is noise level acceptable?

2. Adjust preprocessing:
   ```bash
   --voxel-size 0.015           # Less aggressive downsampling
   --outlier-std-ratio 2.5      # More lenient denoising
   ```

3. Improve feature extraction:
   ```bash
   --k-neighbors 32             # Larger neighborhoods
   --n-keypoints 512            # More keypoints
   ```

4. Add more labeled pairs for supervision

### High Alignment RMSE

**Symptoms:** `mean_icp_rmse > 0.05`

**Solutions:**
1. Visualize alignments:
   - Check `alignment_pair_*.png` outputs
   - Look for systematic errors

2. Adjust alignment:
   ```bash
   --fpfh-radius 0.08           # Larger feature radius
   --dbscan-eps 0.06            # More tolerant clustering
   ```

3. Review break surface detection:
   - Check `*_features.png` visualizations
   - Ensure break surfaces are correctly identified

### Memory Errors

**Symptoms:** OOM crashes

**Solutions:**
```bash
--sample-points 10000         # Reduce point count
--voxel-size 0.03            # Aggressive downsampling
--align-top-n 5              # Fewer alignments
```

### Slow Performance

**Symptoms:** Hours per run

**Solutions:**
1. Enable caching (automatic)
2. Use GPU: `--device cuda`
3. Reduce search space:
   ```bash
   --candidate-top-k 3
   --align-top-n 5
   ```

## Future Enhancements

### Planned Features

1. **Deep Learning Improvements**
   - PointNet++ for point-wise classification
   - Graph Neural Networks for matching
   - Transformer-based alignment

2. **Scalability**
   - Distributed processing with Ray/Dask
   - Cloud-native deployment
   - Real-time visualization

3. **Robustness**
   - Handling partial fragments
   - Missing data imputation
   - Multi-modal fusion (texture + geometry)

4. **Usability**
   - Web interface for annotation
   - Interactive 3D viewer
   - Automated parameter tuning

### Contributing

See `CONTRIBUTING.md` for:
- Code style guidelines
- Testing requirements
- PR process
- Issue templates

## References

- **Open3D**: Point cloud processing
- **PyTorch**: Deep learning framework
- **NetworkX**: Graph algorithms
- **Pydantic**: Configuration validation

## Support

For issues or questions:
- GitHub Issues: Report bugs
- Email: human-ai@cern.ch
- Documentation: This file

---

**Version:** 0.2.0  
**Last Updated:** March 15, 2026  
**Authors:** HumanAI Team
