#!/usr/bin/env python3
"""
Example: Enhanced Visualization Workflow

Demonstrates how to use the new visualization module to create
comprehensive diagnostic plots for reconstruction quality assessment.

Usage:
    python scripts/visualize_reconstruction.py <run_dir>
    python scripts/visualize_reconstruction.py artifacts/latest
"""

import argparse
import json
import logging
from pathlib import Path

import numpy as np

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
LOG = logging.getLogger(__name__)


def load_run_artifacts(run_dir: Path) -> dict:
    """Load artifacts from a pipeline run."""
    results_dir = run_dir / "results"
    
    # Load metrics
    metrics_path = results_dir / "alignment_metrics.json"
    if not metrics_path.exists():
        raise FileNotFoundError(f"Metrics not found: {metrics_path}")
    
    with metrics_path.open("r") as f:
        data = json.load(f)
    
    return {
        "metrics": data.get("metrics", {}),
        "diagnostics": data.get("diagnostics", {}),
        "alignments": data.get("alignment_results", {}),
        "results_dir": results_dir,
    }


def create_quality_visualizations(run_dir: Path) -> None:
    """Create enhanced quality visualizations for a run."""
    from healingstone.visualization import plot_reconstruction_quality_report
    
    LOG.info("Loading run artifacts from: %s", run_dir)
    artifacts = load_run_artifacts(run_dir)
    
    # Create mock assembly object for visualization
    # In real usage, this would come from the actual pipeline
    class MockAssembly:
        def __init__(self, metrics):
            self.completeness = metrics.get("reconstruction_completeness", 0.0)
            
            # Create mock graph
            import networkx as nx
            self.graph = nx.Graph()
            n_nodes = metrics.get("graph_nodes", 0)
            n_edges = metrics.get("graph_edges", 0)
            self.graph.add_nodes_from(range(n_nodes))
            for i in range(min(n_edges, n_nodes - 1)):
                self.graph.add_edge(i, i + 1)
            
            # Mock MST
            self.mst = nx.Graph()
            self.mst.add_nodes_from(range(n_nodes))
            for i in range(min(n_edges, n_nodes - 1)):
                self.mst.add_edge(i, i + 1)
            
            # Mock transforms
            self.global_transforms = {i: np.eye(4) for i in range(n_nodes)}
    
    # Create mock alignment results
    class MockAlignment:
        def __init__(self, data):
            self.success = data.get("success", False)
            self.inlier_rmse = data.get("icp_rmse", float("inf"))
            self.chamfer = data.get("chamfer", float("inf"))
            self.fitness = data.get("fitness", 0.0)
            self.score_prior = data.get("prior_score", 0.0)
    
    alignments = {}
    for key, data in artifacts["alignments"].items():
        parts = key.split("_")
        if len(parts) >= 2:
            try:
                i, j = int(parts[0]), int(parts[1])
                alignments[(i, j)] = MockAlignment(data)
            except ValueError:
                continue
    
    assembly = MockAssembly(artifacts["metrics"])
    
    # Generate quality report
    output_path = artifacts["results_dir"] / "quality_report_enhanced.png"
    LOG.info("Generating quality report...")
    
    plot_reconstruction_quality_report(
        metrics=artifacts["metrics"],
        alignments=alignments,
        assembly=assembly,
        output_path=output_path,
    )
    
    LOG.info("Quality report saved to: %s", output_path)
    
    # Print summary
    print("\n" + "="*60)
    print("RECONSTRUCTION QUALITY SUMMARY")
    print("="*60)
    
    metrics = artifacts["metrics"]
    print(f"\nReconstruction Completeness: {metrics.get('reconstruction_completeness', 0):.1%}")
    print(f"Pairwise Match Accuracy:     {metrics.get('pairwise_match_accuracy', 0):.1%}")
    print(f"Successful Alignments:       {metrics.get('successful_alignments', 0)}/{metrics.get('aligned_pairs', 0)}")
    print(f"Mean ICP RMSE:               {metrics.get('mean_icp_rmse', float('nan')):.5f}")
    print(f"Mean Chamfer Distance:       {metrics.get('mean_chamfer_distance', float('nan')):.5f}")
    
    print(f"\nGraph Statistics:")
    print(f"  Nodes:  {metrics.get('graph_nodes', 0)}")
    print(f"  Edges:  {metrics.get('graph_edges', 0)}")
    
    print(f"\nOutputs:")
    print(f"  Quality Report:  {output_path}")
    print(f"  Run Directory:   {run_dir}")
    print("="*60)


def main():
    parser = argparse.ArgumentParser(
        description="Create enhanced visualizations for pipeline run"
    )
    parser.add_argument(
        "run_dir",
        type=Path,
        help="Path to pipeline run directory (e.g., artifacts/latest)"
    )
    
    args = parser.parse_args()
    
    if not args.run_dir.exists():
        print(f"Error: Run directory not found: {args.run_dir}")
        return 1
    
    try:
        create_quality_visualizations(args.run_dir)
        return 0
    except Exception as exc:
        LOG.error("Visualization failed: %s", exc, exc_info=True)
        return 1


if __name__ == "__main__":
    import sys
    sys.exit(main())
